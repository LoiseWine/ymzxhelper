using System;
using System.Drawing;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using Microsoft.Web.WebView2.Core;

namespace ymzx
{
    public partial class Form1 : Form

    {
        // ����ؼ�
        public Button btnStartStop;
        public Button btnRefresh;
        public Button btnVersionUpdate;
        public Button btnFarmGuide;
        public Button btnYouTube;
        public Button btnGithub;
        public CheckBox checkBoxGPU;
        public WebView2 webView2;

        public Form1()
        {
            // ��������������
            this.Text = "Ԫ��֮��ũ������ 2.0 GPU���ð�";
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.ClientSize = new Size(960, 580);
            this.Icon = new Icon("app.ico");  // ����Ŀ��Ŀ¼����ͼ��

            // ��ʼ�����пؼ�
            InitializeControls();

            // �ڴ������ʱ��ʼ�� WebView2 �ؼ�
            this.Load += Form1_Load;
        }

        private void InitializeControls()
        {
            // ��һ�����򣺰�ť��GPUѡ��
            int buttonWidth = 100;
            int buttonHeight = 30;
            int spacing = 5;
            int startX = spacing;
            int startY = spacing;

            // ����ʼ/ֹͣ����ť
            btnStartStop = new Button();
            btnStartStop.Text = "��ʼ/ֹͣ";
            btnStartStop.Size = new Size(buttonWidth, buttonHeight);
            btnStartStop.Location = new Point(startX, startY);
            btnStartStop.FlatStyle = FlatStyle.Flat;
            btnStartStop.FlatAppearance.BorderSize = 0;
            btnStartStop.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnStartStop.Click += ControlActions.BtnStartStop_Click;
            this.Controls.Add(btnStartStop);

            // ��ˢ�¡���ť
            btnRefresh = new Button();
            btnRefresh.Text = "ˢ��";
            btnRefresh.Size = new Size(buttonWidth, buttonHeight);
            btnRefresh.Location = new Point(startX + (buttonWidth + spacing) * 1, startY);
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnRefresh.Click += ControlActions.BtnRefresh_Click;
            this.Controls.Add(btnRefresh);

            // ���汾���¡���ť
            btnVersionUpdate = new Button();
            btnVersionUpdate.Text = "�汾����";
            btnVersionUpdate.Size = new Size(buttonWidth, buttonHeight);
            btnVersionUpdate.Location = new Point(startX + (buttonWidth + spacing) * 2, startY);
            btnVersionUpdate.FlatStyle = FlatStyle.Flat;
            btnVersionUpdate.FlatAppearance.BorderSize = 0;
            btnVersionUpdate.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnVersionUpdate.Click += ControlActions.BtnVersionUpdate_Click;
            this.Controls.Add(btnVersionUpdate);

            // ��ũ�����ԡ���ť
            btnFarmGuide = new Button();
            btnFarmGuide.Text = "ũ������";
            btnFarmGuide.Size = new Size(buttonWidth, buttonHeight);
            btnFarmGuide.Location = new Point(startX + (buttonWidth + spacing) * 3, startY);
            btnFarmGuide.FlatStyle = FlatStyle.Flat;
            btnFarmGuide.FlatAppearance.BorderSize = 0;
            btnFarmGuide.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnFarmGuide.Click += ControlActions.BtnFarmGuide_Click;
            this.Controls.Add(btnFarmGuide);

            // ��YouTube����ť
            btnYouTube = new Button();
            btnYouTube.Text = "YouTube";
            btnYouTube.Size = new Size(buttonWidth, buttonHeight);
            btnYouTube.Location = new Point(startX + (buttonWidth + spacing) * 4, startY);
            btnYouTube.FlatStyle = FlatStyle.Flat;
            btnYouTube.FlatAppearance.BorderSize = 0;
            btnYouTube.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnYouTube.Click += ControlActions.BtnYouTube_Click;
            this.Controls.Add(btnYouTube);

            // ��Github����ť
            btnGithub = new Button();
            btnGithub.Text = "Github";
            btnGithub.Size = new Size(buttonWidth, buttonHeight);
            btnGithub.Location = new Point(startX + (buttonWidth + spacing) * 5, startY);
            btnGithub.FlatStyle = FlatStyle.Flat;
            btnGithub.FlatAppearance.BorderSize = 0;
            btnGithub.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnGithub.Click += ControlActions.BtnGithub_Click;
            this.Controls.Add(btnGithub);

            // ���ض�����ť
            Button btnMustRead = new Button();
            btnMustRead.Text = "�ض�";
            btnMustRead.Size = new Size(buttonWidth, buttonHeight);
            btnMustRead.Location = new Point(startX + (buttonWidth + spacing) * 6, startY);
            btnMustRead.FlatStyle = FlatStyle.Flat;
            btnMustRead.FlatAppearance.BorderSize = 0;
            btnMustRead.FlatAppearance.MouseOverBackColor = Color.LightBlue;
            btnMustRead.Click += ControlActions.BtnMustRead_Click;
            this.Controls.Add(btnMustRead);

            // ���ұ����� GPU ����ѡ�ʹ�ø�ѡ��
            checkBoxGPU = new CheckBox();
            checkBoxGPU.Text = "����GPU";
            checkBoxGPU.Checked = true; // �̶�Ϊ������GPU
            checkBoxGPU.Enabled = false; // �����û����������ɸ���
            checkBoxGPU.Size = new Size(100, buttonHeight);
            // �����ڵ�һ���Ҳࣨ���ұ�Ե 5 ���أ�
            checkBoxGPU.Location = new Point(this.ClientSize.Width - 100 - spacing, startY);
            // �л���ѡ��ʱ���³�ʼ�� WebView2 ����
            checkBoxGPU.CheckedChanged += async (s, e) =>
            {
                await InitializeWebView2();
            };
            this.Controls.Add(checkBoxGPU);

            // �ڶ�������WebView2 �ؼ����ޱ߿�λ�ý�����һ���·�
            webView2 = new WebView2();
            webView2.Location = new Point(0, buttonHeight + 2 * spacing);
            webView2.Size = new Size(960, 540);
            this.Controls.Add(webView2);
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            await InitializeWebView2();
        }

        // ���� GPU ѡ���ʼ�� WebView2 �ؼ�
        public async Task InitializeWebView2()
        {
            try
            {
                var options = new CoreWebView2EnvironmentOptions();
                if (!checkBoxGPU.Checked)
                {
                    options.AdditionalBrowserArguments = "--disable-gpu";
                }
                var env = await CoreWebView2Environment.CreateAsync(null, null, options);
                await webView2.EnsureCoreWebView2Async(env);
                // ����ָ����ҳ
                webView2.CoreWebView2.Navigate("https://gamer.qq.com/v2/game/96897?ichannel=pcgames0Fpcgames1");
            }
            catch (Exception ex)
            {
                MessageBox.Show("WebView2 ��ʼ��ʧ��: " + ex.Message);
            }
        }
    }
}
