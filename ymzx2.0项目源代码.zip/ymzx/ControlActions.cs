﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

namespace ymzx
{
    public static class ControlActions
    {
        // 用于控制自动化循环的取消标记
        private static CancellationTokenSource? automationCts = null;

        // “开始/停止”按钮点击事件
        public static async void BtnStartStop_Click(object? sender, EventArgs e)
        {
            // 获取当前 Form1 实例
            if (!(sender is Button btn)) return;
            Form form = btn.FindForm();
            if (!(form is Form1 form1)) return;

            if (automationCts == null)
            {
                // 开始自动化循环
                automationCts = new CancellationTokenSource();
                btn.Text = "停止"; // 更改按钮文字为“停止”
                _ = RunAutomationLoop(form1.webView2, automationCts.Token).ContinueWith(t =>
                {
                    // 循环结束后在 UI 线程中恢复按钮文字
                    form.Invoke((Action)(() => { btn.Text = "开始/停止"; }));
                    automationCts = null;
                });
            }
            else
            {
                // 停止自动化循环
                automationCts.Cancel();
                automationCts = null;
                btn.Text = "开始/停止";
            }
        }

        // 自动化循环操作，在每次循环开始前先激活网页
        private static async Task RunAutomationLoop(WebView2 webView, CancellationToken token)
        {
            try
            {
                while (!token.IsCancellationRequested)
                {
                    // 新增步骤：激活网页（确保网页获得焦点）
                    await ActivateWebPage(webView);

                    // 步骤1：按下并释放 R 键
                    await PressKey(webView, "R");
                    if (token.IsCancellationRequested) break;

                    // 步骤2：按住 A 键 1.2 秒
                    await HoldKey(webView, "A", 1200);
                    if (token.IsCancellationRequested) break;

                    // 步骤3：按下并释放 Q 键
                    await PressKey(webView, "Q");
                    if (token.IsCancellationRequested) break;

                    // 步骤4：连续按下 10 次 R 键，每次间隔 1 秒
                    for (int i = 0; i < 10; i++)
                    {
                        await PressKey(webView, "R");
                        if (token.IsCancellationRequested) break;
                        await Task.Delay(1000, token);
                    }
                    if (token.IsCancellationRequested) break;

                    // 步骤5：等待 50 秒
                    await Task.Delay(50000, token);
                }
            }
            catch (TaskCanceledException)
            {
                // 正常取消时抛出的异常，无需处理
            }
        }

        // 辅助方法：激活网页，使用 IIFE 包装，模拟点击页面正中央
        private static async Task ActivateWebPage(WebView2 webView)
        {
            if (webView.CoreWebView2 != null)
            {
                string script = @"
                    (function(){
                        var x = window.innerWidth / 2;
                        var y = window.innerHeight / 2;
                        var evt = new MouseEvent('click', {
                            bubbles: true,
                            cancelable: true,
                            view: window,
                            clientX: x,
                            clientY: y
                        });
                        document.elementFromPoint(x, y).dispatchEvent(evt);
                    })();
                ";
                await webView.CoreWebView2.ExecuteScriptAsync(script);
            }
        }

        // 辅助方法：模拟一次按键（包括 keydown 与 keyup）
        private static async Task PressKey(WebView2 webView, string key)
        {
            await SimulateKeyEvent(webView, key, "keydown");
            await SimulateKeyEvent(webView, key, "keyup");
        }

        // 辅助方法：模拟按住键（先发送 keydown，延时后发送 keyup）
        private static async Task HoldKey(WebView2 webView, string key, int durationMilliseconds)
        {
            await SimulateKeyEvent(webView, key, "keydown");
            await Task.Delay(durationMilliseconds);
            await SimulateKeyEvent(webView, key, "keyup");
        }

        // 辅助方法：通过注入 JavaScript 代码模拟键盘事件
        private static async Task SimulateKeyEvent(WebView2 webView, string key, string eventType)
        {
            if (webView.CoreWebView2 != null)
            {
                // 如果 key 是单个字符，则计算 keyCode，code 以 KeyX 格式（X为大写字母）
                int keyCode = key.Length == 1 ? (int)key[0] : 0;
                string code = key.Length == 1 ? $"Key{key.ToUpper()}" : "";
                string script = $@"
                    (function(){{
                        var evt = new KeyboardEvent('{eventType}', {{
                            key: '{key}',
                            keyCode: {keyCode},
                            code: '{code}',
                            bubbles: true
                        }});
                        document.dispatchEvent(evt);
                    }})();
                ";
                await webView.CoreWebView2.ExecuteScriptAsync(script);
            }
        }

        // “刷新”按钮点击事件：刷新 WebView2 网页
        public static void BtnRefresh_Click(object? sender, EventArgs e)
        {
            if (sender is Button btn)
            {
                Form form = btn.FindForm();
                if (form is Form1 form1)
                {
                    form1.webView2?.CoreWebView2?.Reload();
                }
            }
        }

        // “版本更新”按钮点击事件：弹出显示更新信息的对话框
        public static void BtnVersionUpdate_Click(object? sender, EventArgs e)
        {
            // 创建新窗体作为弹窗
            Form updateForm = new Form();
            updateForm.Text = "版本更新";
            updateForm.Size = new System.Drawing.Size(400, 200);
            updateForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            updateForm.MaximizeBox = false;
            updateForm.MinimizeBox = false;
            updateForm.StartPosition = FormStartPosition.CenterParent;

            // 使用 RichTextBox 显示文本信息，并启用 URL 自动检测
            RichTextBox rtb = new RichTextBox();
            rtb.Dock = DockStyle.Fill;
            rtb.ReadOnly = true;
            rtb.DetectUrls = true;
            rtb.Text = "此软件开源免费，禁止任何商业交易；\r\n" +
                       "作者星宝Sakura；QQ群 791045954;\r\n" +
                       "星宝农场频道 https://pd.qq.com/s/dsjxwwyuq \r\n" +
                       "蓝奏云更新 https://wwtu.lanzoue.com/b0sxhgj9i 密码:e5fg ";
            rtb.LinkClicked += (s, args) =>
            {
                try
                {
                    Process.Start(new ProcessStartInfo(args.LinkText!) { UseShellExecute = true });
                }
                catch (Exception ex)
                {
                    MessageBox.Show("无法打开链接: " + ex.Message);
                }
            };

            updateForm.Controls.Add(rtb);
            updateForm.ShowDialog();
        }

        // “农场攻略”按钮点击事件：打开指定网址
        public static void BtnFarmGuide_Click(object? sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo("https://space.bilibili.com/3493086715972236") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开链接: " + ex.Message);
            }
        }

        // “YouTube”按钮点击事件：打开指定网址
        public static void BtnYouTube_Click(object? sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo("https://www.youtube.com/@LoiseWine") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开链接: " + ex.Message);
            }
        }

        // “Github”按钮点击事件：打开指定网址
        public static void BtnGithub_Click(object? sender, EventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo("https://github.com/LoiseWine/ymzxhelper") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开链接: " + ex.Message);
            }
        }

        // 新增：“必读”按钮点击事件，点击后弹窗显示预设的文字
        // “必读”按钮点击事件：显示标准 MessageBox 弹窗，文本不可复制
        public static void BtnMustRead_Click(object? sender, EventArgs e)
        {
            string message = "必读事项：\r\n1.若无按键映射，请点击一键重置；\r\n2.不建议最小化，可能影响挂机；\r\n3.请自己调整最低画质，关闭声音；\r\n4.循环流程：R复位，A走向无人机，Q启动无人机，R消除钓鱼和对话弹窗，50秒循环一次；";
            MessageBox.Show(message, "必读", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
