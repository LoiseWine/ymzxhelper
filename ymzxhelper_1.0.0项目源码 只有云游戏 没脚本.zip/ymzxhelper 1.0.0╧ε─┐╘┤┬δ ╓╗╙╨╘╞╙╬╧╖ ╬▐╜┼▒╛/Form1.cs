using System;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;
using System.Drawing; // Icon 类所在的命名空间

namespace ymzxhelper
{
    public partial class Form1 : Form
    {
        private WebView2 webView;

        public Form1()
        {
            InitializeComponent();
            // 设置窗体的图标为 app.ico
            try
            {
                this.Icon = new Icon("app.ico");
            }
            catch (Exception ex)
            {
                MessageBox.Show("加载图标失败：" + ex.Message);
            }

            // 订阅窗体加载事件
            this.Load += Form1_Load;
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            // 设置窗体标题和固定大小
            this.Text = "元梦之星农场助手";
            this.ClientSize = new System.Drawing.Size(1280, 720);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // 创建 WebView2 控件并填充整个窗体
            webView = new WebView2
            {
                Dock = DockStyle.Fill
            };
            this.Controls.Add(webView);

            // 异步初始化 WebView2 环境
            await webView.EnsureCoreWebView2Async(null);

            

            // 导航到目标网站（可自行修改为你需要的网址）
            webView.CoreWebView2.Navigate("https://gamer.qq.com/v2/game/96897?ichannel=pcgames0Fpcgames1");
        }
    }
}